function text_hide(){
    let text = document.getElementById('text');
    if(text){
        if(text.style.color === 'black'){
            text.style.color = '#ebe4dc'
        }else{
            text.style.color = 'black'
        }
    }
}

function traslation_hide(){
    let text = document.getElementById('translation');
    if(text){
        if(text.style.color === 'black'){
            text.style.color = '#ebe4dc'
        }else{
            text.style.color = 'black'
        }
    }
}